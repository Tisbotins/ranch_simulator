using System.Collections.Generic;
using UnityEngine;

public class RanchTrapSystem : MonoBehaviour
{
    public const int TrapPackSize = 3;
    public const int BaseMaxCarriedTraps = 12;

    public int TrapCount { get; private set; }
    public int ActivePlacedTrapCount => placedTraps.Count;
    public int MaxCarriedTraps => BaseMaxCarriedTraps + (core == null ? 0 : core.Progression.EngineeringTraining * 2);
    public float TrapPackCost => 180f + (core == null ? 0f : core.Waves.HighestWaveCleared * 12f);
    public float TrapDamage => (core == null ? 90f : 70f + core.Shop.CurrentSwordDamage * 0.85f) *
                               (core == null ? 1f : 1f + core.Progression.EngineeringTraining * 0.08f);
    public float TrapRadius => 2.35f;
    public float TrapStunDuration => 2.25f;
    public float TrapLifetime => 120f;

    private readonly List<RanchTrap> placedTraps = new List<RanchTrap>();
    private RanchGameCore core;
    private float placeCooldown;

    public void Initialize(RanchGameCore gameCore)
    {
        core = gameCore;
    }

    private void Update()
    {
        if (placeCooldown > 0f)
            placeCooldown -= Time.deltaTime;

        if (core == null || core.Player == null || core.GameWon || core.Health.IsDead ||
            core.Shop.IsOpen || core.Progression.IsOpen || core.Settings.IsOpen || Cursor.visible)
        {
            return;
        }

        placedTraps.RemoveAll(trap => trap == null);

        if (!core.Equipment.ExtraSlotActive)
            return;

        if (Input.GetMouseButtonDown(0) || Input.GetKeyDown(KeyCode.F))
            TryPlaceTrap();
    }

    public void BuyTrapPack()
    {
        int room = MaxCarriedTraps - TrapCount;
        if (room <= 0)
        {
            core.ShowMessage("Your ranch trap pouch is full.");
            return;
        }

        float cost = TrapPackCost;
        if (!core.Inventory.TrySpendMoney(cost))
        {
            core.ShowMessage("Need $" + cost.ToString("F0") + " to buy ranch traps.");
            return;
        }

        int amount = Mathf.Min(TrapPackSize, room);
        TrapCount += amount;
        core.Progression.AddExperience(10f, "Trap supply purchase");
        core.ShowMessage("Bought " + amount + " Ranch Trap" + (amount == 1 ? "" : "s") + ". Select Slot 3 and left-click or press F to place one.", 7f);
        core.Save.RequestSave();
        core.NotifyResourcesChanged();
    }

    public void RestoreState(int trapCount)
    {
        TrapCount = Mathf.Clamp(trapCount, 0, MaxCarriedTraps);
        PrepareForLoad();
    }

    public void PrepareForLoad()
    {
        foreach (RanchTrap trap in placedTraps)
        {
            if (trap != null)
                Destroy(trap.gameObject);
        }

        placedTraps.Clear();
    }

    public void NotifyTrapRemoved(RanchTrap trap)
    {
        placedTraps.Remove(trap);
    }

    private void TryPlaceTrap()
    {
        if (placeCooldown > 0f)
            return;

        if (TrapCount <= 0)
        {
            core.ShowMessage("No Ranch Traps left. Buy more from the Defense tab in the shop.");
            return;
        }

        Vector3 position = GetPlacementPosition();
        if (!IsPlacementClear(position))
        {
            core.ShowMessage("Move a little farther away from the nearest trap before placing another one.");
            return;
        }

        TrapCount--;
        placeCooldown = 0.35f;

        GameObject trapObject = new GameObject("Ranch Trap");
        trapObject.transform.position = position;
        RanchTrap trap = trapObject.AddComponent<RanchTrap>();
        trap.Initialize(core, this, TrapDamage, TrapRadius, TrapStunDuration, TrapLifetime);
        trap.BuildVisuals();

        placedTraps.Add(trap);
        core.ShowMessage("Ranch Trap placed. It will snap on the first enemy that steps near it.");
        core.Save.RequestSave();
        core.NotifyResourcesChanged();
    }

    private Vector3 GetPlacementPosition()
    {
        Transform player = core.Player.transform;
        Vector3 position = player.position + player.forward * 2.35f;
        position.y = player.position.y;

        RaycastHit hit;
        if (Physics.Raycast(position + Vector3.up * 5f, Vector3.down, out hit, 12f))
            position = hit.point + Vector3.up * 0.06f;
        else
            position.y = 0.06f;

        return position;
    }

    private bool IsPlacementClear(Vector3 position)
    {
        foreach (RanchTrap trap in placedTraps)
        {
            if (trap == null)
                continue;

            if (Vector3.Distance(position, trap.transform.position) < 1.5f)
                return false;
        }

        return true;
    }
}
