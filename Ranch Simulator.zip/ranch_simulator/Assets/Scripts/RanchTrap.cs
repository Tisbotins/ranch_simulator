using UnityEngine;

public class RanchTrap : MonoBehaviour
{
    private RanchGameCore core;
    private RanchTrapSystem owner;
    private TextMesh label;
    private float damage;
    private float triggerRadius;
    private float stunDuration;
    private float lifetimeRemaining;
    private bool triggered;

    public void Initialize(
        RanchGameCore gameCore,
        RanchTrapSystem trapOwner,
        float trapDamage,
        float radius,
        float stun,
        float lifetime)
    {
        core = gameCore;
        owner = trapOwner;
        damage = Mathf.Max(1f, trapDamage);
        triggerRadius = Mathf.Max(0.5f, radius);
        stunDuration = Mathf.Max(0f, stun);
        lifetimeRemaining = Mathf.Max(5f, lifetime);
    }

    private void Update()
    {
        if (triggered)
            return;

        if (core == null || core.Waves == null || core.Health.IsDead || core.GameWon)
            return;

        lifetimeRemaining -= Time.deltaTime;
        if (lifetimeRemaining <= 0f)
        {
            Expire(false);
            return;
        }

        if (label != null)
            label.text = "Ranch Trap\n" + Mathf.CeilToInt(lifetimeRemaining) + "s";

        foreach (RanchEnemy enemy in core.Waves.ActiveEnemies)
        {
            if (enemy == null)
                continue;

            if (Vector3.Distance(transform.position, enemy.transform.position) <= triggerRadius)
            {
                Trigger(enemy);
                return;
            }
        }
    }

    public void BuildVisuals()
    {
        CreatePart(
            "Trap Base",
            PrimitiveType.Cylinder,
            new Vector3(0f, 0.04f, 0f),
            new Vector3(1.25f, 0.08f, 1.25f),
            Color.gray
        );

        CreatePart(
            "Trap Ring North",
            PrimitiveType.Cube,
            new Vector3(0f, 0.13f, 0.48f),
            new Vector3(1.05f, 0.12f, 0.13f),
            new Color(0.30f, 0.30f, 0.30f)
        );

        CreatePart(
            "Trap Ring South",
            PrimitiveType.Cube,
            new Vector3(0f, 0.13f, -0.48f),
            new Vector3(1.05f, 0.12f, 0.13f),
            new Color(0.30f, 0.30f, 0.30f)
        );

        CreatePart(
            "Trap Ring East",
            PrimitiveType.Cube,
            new Vector3(0.48f, 0.13f, 0f),
            new Vector3(0.13f, 0.12f, 1.05f),
            new Color(0.30f, 0.30f, 0.30f)
        );

        CreatePart(
            "Trap Ring West",
            PrimitiveType.Cube,
            new Vector3(-0.48f, 0.13f, 0f),
            new Vector3(0.13f, 0.12f, 1.05f),
            new Color(0.30f, 0.30f, 0.30f)
        );

        for (int i = 0; i < 8; i++)
        {
            float angle = i * Mathf.PI * 2f / 8f;
            Vector3 localPosition = new Vector3(Mathf.Cos(angle) * 0.42f, 0.28f, Mathf.Sin(angle) * 0.42f);
            GameObject spike = CreatePart(
                "Trap Tooth",
                PrimitiveType.Cube,
                localPosition,
                new Vector3(0.08f, 0.32f, 0.08f),
                new Color(0.86f, 0.82f, 0.62f)
            );
            spike.transform.localRotation = Quaternion.Euler(35f, -angle * Mathf.Rad2Deg, 0f);
        }

        GameObject labelObject = new GameObject("Trap Label");
        labelObject.transform.SetParent(transform, false);
        labelObject.transform.localPosition = new Vector3(0f, 1.15f, 0f);
        label = labelObject.AddComponent<TextMesh>();
        label.text = "Ranch Trap";
        label.fontSize = 28;
        label.characterSize = 0.08f;
        label.anchor = TextAnchor.MiddleCenter;
        label.alignment = TextAlignment.Center;
        label.color = Color.white;
        labelObject.AddComponent<RanchBillboard>();
    }

    private GameObject CreatePart(
        string objectName,
        PrimitiveType primitiveType,
        Vector3 localPosition,
        Vector3 localScale,
        Color color)
    {
        GameObject part = GameObject.CreatePrimitive(primitiveType);
        part.name = objectName;
        part.transform.SetParent(transform, false);
        part.transform.localPosition = localPosition;
        part.transform.localScale = localScale;

        Collider collider = part.GetComponent<Collider>();
        if (collider != null)
        {
            collider.enabled = false;
            Destroy(collider);
        }

        Renderer renderer = part.GetComponent<Renderer>();
        if (renderer != null)
            renderer.material = RanchWorldBuilder.CreateRuntimeMaterial(color);

        return part;
    }

    private void Trigger(RanchEnemy enemy)
    {
        if (enemy == null)
            return;

        triggered = true;
        enemy.Stun(stunDuration);
        enemy.TakeDamage(damage, true, 3.5f);

        if (core != null)
        {
            core.Progression.AddExperience(6f, "Ranch Trap triggered");
            core.ShowMessage("Ranch Trap snapped shut for " + damage.ToString("F0") + " damage.", 4f);
        }

        Expire(true);
    }

    private void Expire(bool triggeredByEnemy)
    {
        if (owner != null)
            owner.NotifyTrapRemoved(this);

        if (!triggeredByEnemy && core != null)
            core.ShowMessage("A Ranch Trap expired before anything stepped on it.", 3f);

        Destroy(gameObject);
    }
}
