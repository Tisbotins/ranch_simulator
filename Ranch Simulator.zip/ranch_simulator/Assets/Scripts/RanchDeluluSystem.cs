using System.Collections.Generic;
using UnityEngine;

public class RanchDeluluSystem : MonoBehaviour
{
    public bool WandUnlocked { get; private set; }
    public int ActiveProtectorCount => activeProtectors.Count;
    public int MaxActiveProtectors => Mathf.Clamp(2 + (core == null ? 0 : core.Progression.EngineeringTraining / 2), 2, 6);
    public float WandCost => 4200f;
    public float CooldownRemaining => summonCooldownRemaining;
    public float SummonCooldown => Mathf.Max(3.5f, 9f - (core == null ? 0f : core.Progression.EngineeringTraining * 0.45f));
    public float SummonStaminaCost => 18f;
    public float ProtectorLifetime => 75f + (core == null ? 0f : core.Progression.EngineeringTraining * 8f);
    public float ProtectorDamage =>
        (core == null ? 45f : 28f + core.Shop.CurrentSwordDamage * 0.42f) *
        (core == null ? 1f : core.Progression.DamageMultiplier) *
        (core == null ? 1f : 1f + core.Progression.CombatTraining * 0.04f);

    private readonly List<RanchDeluluProtector> activeProtectors = new List<RanchDeluluProtector>();
    private RanchGameCore core;
    private float summonCooldownRemaining;

    public void Initialize(RanchGameCore gameCore)
    {
        core = gameCore;
    }

    private void Update()
    {
        activeProtectors.RemoveAll(protector => protector == null);

        if (summonCooldownRemaining > 0f)
            summonCooldownRemaining -= Time.deltaTime;

        if (core == null || core.Player == null || core.GameWon || core.Health.IsDead ||
            core.Shop.IsOpen || core.Progression.IsOpen || core.Settings.IsOpen || Cursor.visible)
        {
            return;
        }

        if (!core.Equipment.WandSlotActive)
            return;

        if (Input.GetMouseButtonDown(0) || Input.GetKeyDown(KeyCode.F))
            TrySummonDelulu();
    }

    public void BuyWand()
    {
        if (WandUnlocked)
        {
            core.Equipment.SelectSlot(3);
            core.ShowMessage("Delulu Wand equipped in Slot 4.");
            return;
        }

        if (!core.Inventory.TrySpendMoney(WandCost))
        {
            core.ShowMessage("Need $" + WandCost.ToString("F0") + " to buy the Delulu Wand.");
            return;
        }

        WandUnlocked = true;
        core.Progression.AddExperience(85f, "Delulu Wand unlocked");
        core.Equipment.SelectSlot(3);
        core.Save.RequestSave();
        core.NotifyResourcesChanged();
        core.ShowMessage("Delulu Wand unlocked. Select Slot 4, then left-click or press F to summon a Delulu protector.", 8f);
    }

    public void RestoreState(bool wandUnlocked)
    {
        WandUnlocked = wandUnlocked;
        PrepareForLoad();
    }

    public void PrepareForLoad()
    {
        foreach (RanchDeluluProtector protector in activeProtectors)
        {
            if (protector != null)
                Destroy(protector.gameObject);
        }

        activeProtectors.Clear();
        summonCooldownRemaining = 0f;
    }

    public void NotifyProtectorRemoved(RanchDeluluProtector protector)
    {
        activeProtectors.Remove(protector);
    }

    private void TrySummonDelulu()
    {
        if (!WandUnlocked)
        {
            core.ShowMessage("Buy the Delulu Wand from the Defense tab first.");
            return;
        }

        if (summonCooldownRemaining > 0f)
        {
            core.ShowMessage("The Delulu Wand is recharging for " + Mathf.CeilToInt(summonCooldownRemaining) + "s.");
            return;
        }

        if (activeProtectors.Count >= MaxActiveProtectors)
        {
            core.ShowMessage("You already have the maximum number of Delulu protectors active.");
            return;
        }

        if (!core.Stamina.TrySpend(SummonStaminaCost))
        {
            core.ShowMessage("Not enough stamina to summon Delulu.");
            return;
        }

        Vector3 position = GetSummonPosition();
        GameObject protectorObject = new GameObject("Delulu Protector");
        protectorObject.transform.position = position;

        RanchDeluluProtector protector = protectorObject.AddComponent<RanchDeluluProtector>();
        protector.Initialize(
            core,
            this,
            ProtectorDamage,
            ProtectorLifetime,
            1.05f,
            2.05f,
            28f
        );
        protector.BuildVisuals();

        activeProtectors.Add(protector);
        summonCooldownRemaining = SummonCooldown;

        core.Progression.AddExperience(5f, "Delulu summoned");
        core.ShowMessage("Delulu has entered the ranch. It will fight enemies for you.", 5f);
        core.Save.RequestSave();
        core.NotifyResourcesChanged();
    }

    private Vector3 GetSummonPosition()
    {
        Transform player = core.Player.transform;
        Vector3 right = player.right * Random.Range(-1.25f, 1.25f);
        Vector3 position = player.position + player.forward * 2.0f + right;
        position.y = player.position.y;

        RaycastHit hit;
        if (Physics.Raycast(position + Vector3.up * 5f, Vector3.down, out hit, 12f))
            position = hit.point + Vector3.up * 1.05f;
        else
            position.y = 1.05f;

        return position;
    }
}
