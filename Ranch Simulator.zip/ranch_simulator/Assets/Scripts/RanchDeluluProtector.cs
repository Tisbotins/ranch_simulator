using UnityEngine;

public class RanchDeluluProtector : MonoBehaviour
{
    private RanchGameCore core;
    private RanchDeluluSystem owner;
    private TextMesh label;
    private float damage;
    private float lifetimeRemaining;
    private float attackInterval;
    private float attackRange;
    private float acquisitionRange;
    private float attackTimer;
    private float moveSpeed;
    private float orbitSeed;

    public void Initialize(
        RanchGameCore gameCore,
        RanchDeluluSystem deluluOwner,
        float protectorDamage,
        float lifetime,
        float interval,
        float range,
        float acquisition)
    {
        core = gameCore;
        owner = deluluOwner;
        damage = Mathf.Max(1f, protectorDamage);
        lifetimeRemaining = Mathf.Max(10f, lifetime);
        attackInterval = Mathf.Max(0.25f, interval);
        attackRange = Mathf.Max(0.5f, range);
        acquisitionRange = Mathf.Max(2f, acquisition);
        moveSpeed = 4.15f;
        orbitSeed = Random.Range(0f, 1000f);
    }

    private void Update()
    {
        if (core == null || core.Player == null || core.Health.IsDead || core.GameWon)
        {
            Expire(false);
            return;
        }

        lifetimeRemaining -= Time.deltaTime;
        if (lifetimeRemaining <= 0f)
        {
            Expire(true);
            return;
        }

        if (label != null)
            label.text = "Delulu\n" + Mathf.CeilToInt(lifetimeRemaining) + "s";

        if (core.Shop.IsOpen || core.Progression.IsOpen || core.Settings.IsOpen)
            return;

        RanchEnemy target = FindNearestEnemy();
        if (target == null)
        {
            OrbitPlayer();
            return;
        }

        MoveToward(target.transform.position, attackRange * 0.78f);
        TryAttack(target);
    }

    public void BuildVisuals()
    {
        CreatePart(
            "Delulu Body",
            PrimitiveType.Capsule,
            Vector3.zero,
            new Vector3(0.62f, 0.82f, 0.62f),
            new Color(0.82f, 0.32f, 0.95f)
        );

        CreatePart(
            "Delulu Hat",
            PrimitiveType.Cylinder,
            new Vector3(0f, 0.82f, 0f),
            new Vector3(0.62f, 0.12f, 0.62f),
            new Color(1f, 0.77f, 0.22f)
        );

        CreatePart(
            "Delulu Wand",
            PrimitiveType.Cube,
            new Vector3(0.42f, 0.35f, 0.18f),
            new Vector3(0.08f, 0.72f, 0.08f),
            new Color(0.98f, 0.94f, 0.72f),
            new Vector3(0f, 0f, -28f)
        );

        CreatePart(
            "Delulu Glow",
            PrimitiveType.Sphere,
            new Vector3(0.55f, 0.74f, 0.18f),
            new Vector3(0.24f, 0.24f, 0.24f),
            new Color(1f, 1f, 1f)
        );

        GameObject labelObject = new GameObject("Delulu Label");
        labelObject.transform.SetParent(transform, false);
        labelObject.transform.localPosition = new Vector3(0f, 1.45f, 0f);
        label = labelObject.AddComponent<TextMesh>();
        label.text = "Delulu";
        label.fontSize = 36;
        label.characterSize = 0.075f;
        label.anchor = TextAnchor.MiddleCenter;
        label.alignment = TextAlignment.Center;
        label.color = Color.white;
        labelObject.AddComponent<RanchBillboard>();
    }

    private RanchEnemy FindNearestEnemy()
    {
        if (core.Waves == null)
            return null;

        RanchEnemy nearest = null;
        float nearestDistance = acquisitionRange;

        foreach (RanchEnemy enemy in core.Waves.ActiveEnemies)
        {
            if (enemy == null)
                continue;

            float distance = Vector3.Distance(transform.position, enemy.transform.position);
            if (distance <= nearestDistance)
            {
                nearest = enemy;
                nearestDistance = distance;
            }
        }

        return nearest;
    }

    private void OrbitPlayer()
    {
        Vector3 playerPosition = core.Player.transform.position;
        float angle = Time.time * 1.35f + orbitSeed;
        Vector3 desired = playerPosition + new Vector3(
            Mathf.Cos(angle) * 2.6f,
            0f,
            Mathf.Sin(angle) * 2.6f
        );
        desired.y = playerPosition.y + 1.05f;
        MoveToward(desired, 0.25f);
    }

    private void MoveToward(Vector3 destination, float stopDistance)
    {
        destination.y = transform.position.y;
        Vector3 difference = destination - transform.position;

        if (difference.magnitude <= stopDistance)
            return;

        Vector3 movement = difference.normalized * moveSpeed * Time.deltaTime;
        transform.position += movement;

        Vector3 facing = difference;
        facing.y = 0f;
        if (facing.sqrMagnitude > 0.01f)
            transform.rotation = Quaternion.LookRotation(facing);
    }

    private void TryAttack(RanchEnemy target)
    {
        attackTimer += Time.deltaTime;
        if (attackTimer < attackInterval)
            return;

        if (target == null || Vector3.Distance(transform.position, target.transform.position) > attackRange)
            return;

        attackTimer = 0f;
        target.TakeDamage(damage, true, 0.65f);

        if (Random.value < 0.22f)
            target.Stun(0.35f);
    }

    private GameObject CreatePart(
        string objectName,
        PrimitiveType primitiveType,
        Vector3 localPosition,
        Vector3 localScale,
        Color color,
        Vector3? localEulerAngles = null)
    {
        GameObject part = GameObject.CreatePrimitive(primitiveType);
        part.name = objectName;
        part.transform.SetParent(transform, false);
        part.transform.localPosition = localPosition;
        part.transform.localScale = localScale;
        part.transform.localEulerAngles = localEulerAngles ?? Vector3.zero;

        Collider collider = part.GetComponent<Collider>();
        if (collider != null)
        {
            collider.enabled = false;
            Destroy(collider);
        }

        Renderer renderer = part.GetComponent<Renderer>();
        if (renderer != null)
            renderer.material = RanchWorldBuilder.CreateRuntimeMaterial(color);

        return part;
    }

    private void Expire(bool timedOut)
    {
        if (owner != null)
            owner.NotifyProtectorRemoved(this);

        if (timedOut && core != null)
            core.ShowMessage("A Delulu protector faded away.", 3f);

        Destroy(gameObject);
    }
}
